"""
deriv:  Utilities calculating derivatives useful for statistical computation
"""

from obsinfo import dllsteps, obsinfo

__version__ = '0.1'

__all__ = ['dllsteps', 'obsinfo']
