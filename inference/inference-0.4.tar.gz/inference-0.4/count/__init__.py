"""
count: Tools for inference with counting processes
"""

import onoff

__version__ = '0.1'

__all__ = ['onoff']
