"""
Objects supporting plotting of bivariate functions arising in statistics,
e.g., pdfs, log-likelihoods, and chi**2 functions.

Much of the code is adapted from Matplotlib's contour_demo.py.

Adapted from prior code 10 July 2008 by Tom Loredo
"""

from numpy import *
import scipy.stats as stats
from inference.utils import pl

__all__ = ['plot_bivar']


labels = { 'fontsize' : 14 }

crosshair_p = { 'color' : '0.5', 'linestyle' : ':' , 'linewidth' : '1.5'}

def crosshair(ax, x, y):
    ax.axvline(x, **crosshair_p)
    ax.axhline(y, **crosshair_p)

def normal_levels(n):
    """
    Return an array of values of the probability within a +- k*sigma region
    centered on the mean of a normal distribution, for k=1 to n.
    """
    c1cdf = stats.chi2(1).cdf
    levels = []
    for i in range(1,n+1):
        levels.append(c1cdf(i**2))
    return array(levels)

normal_levels5 = normal_levels(5)
normal_levels6 = normal_levels(6)
#array([c1cdf(1), c1cdf(4), c1cdf(9), c1cdf(16), c1cdf(25)])

# Ten colors to cycle contours through.
colors=('blue', 'darkgreen', 'firebrick', 'saddlebrown', 'dimgray',
        'k', 'k', 'k', 'k', 'k')

# chi-squared dist'n with 2 dof, for finding default 2-D contour levels.
chisqr_2 = stats.chi2(1)

def plot_bivar(x, y, logpdf, plevels=normal_levels6, cross=None,
               xlabel='X', ylabel='Y', colors=colors, gscale=False):
    """
    Plot contours (and optionally a grayscale image and crosshairs) using a
    2-D grid of values of a function evaluated on linearly spaced grids in
    x and y.  Default contour levels are suitable for functions interpretable
    as a bivariate log-pdf.
    
    The grid `logpdf` is interpreted so that logpdf[i,j] is the value for
    (x[i], y[j]).  Note that this means that x increases along *columns*
    (different choices of row, i).  This is the reverse interpretation
    of Matplotlib's contour and imshow; we use a transposed view of logpdf
    for the plotting.
    """
    # *** Add args to handle chi**2 input; internally convert to log-like.
    # This is based on Matplotlib's contour_demo.py
    xg, yg = pl.meshgrid(x, y)
    xlo, xhi = xg[0,0], xg[0,-1]
    ylo, yhi = yg[0,0], yg[-1,0]
    logpdf = logpdf.transpose()
    logmax = logpdf.max()
    dlogpdf = logpdf - logmax
    # Base levels on bivariate normal.
    levels = -0.5 * chisqr_2.ppf(plevels)

    # Plot a grayscale image displaying tails beyond the lowest level.
    if gscale:
        lo, hi = 10*levels.min(), 0.
        im = pl.imshow(dlogpdf, interpolation='bilinear', origin='lower', aspect='auto',
                    vmin=lo, vmax=hi, cmap=pl.cm.gray, extent=(xlo, xhi, ylo, yhi))

    # Plot contours on top.
    CS = pl.contour(xg, yg, dlogpdf, levels, colors=colors, origin='lower', linewidths=1)

    # Make a colorbar for the contour lines.
    #CB = colorbar(CS, shrink=0.6, extend='both')

    #title('Doublet Periodogram')
    pl.xlabel(xlabel, fontsize=14)
    pl.ylabel(ylabel, fontsize=14)
    #hot()  # Now change the colormap for the contour lines and colorbar
    #flag()

    # We can still add a colorbar for the image, too.
    if gscale:
        CBI = pl.colorbar(im, orientation='horizontal', shrink=0.8)

    if cross:
        xc, yc = cross
        xlo, xhi = xlim()
        ylo, yhi = ylim()
        pl.hlines(yc, xlo, xhi, 'teal')
        pl.vlines(xc, ylo, yhi, 'teal')
    # This makes the original colorbar look a bit out of place,
    # so let's improve its position.
    #l,b,w,h = gca().get_position().bounds
    #ll,bb,ww,hh = CB.ax.get_position().bounds
    #CB.ax.set_position([ll, b+0.1*h, ww, h*0.8])
