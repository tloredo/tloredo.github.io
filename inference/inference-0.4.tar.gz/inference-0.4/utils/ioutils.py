import os
import os.path as path
from numpy import ndarray, savez, load

__all__ = ['backup', 'safe_open', 'ArrayStore']

def backup(fname):
    """
    Backup any existing file with name fname, up to two levels.  If a
    file fname exists, the existing copy is renamed with a '%'appended
    to its name.  If such a backup already exists, it is renamed with an
    additional '%' appended, overwriting any previous such file.
    """
    if path.exists(fname):
        bname = fname + '%'
        if path.exists(bname):
            bbname = bname + '%'
            os.rename(bname, bbname)
        os.rename(fname, bname)

def safe_open(name, opener=None, *args, **kwds):
    """
    Open a file by name for writing, backing up an existing version up
    to two levels.  If the file exists, the existing copy is renamed with 
    a '%'appended to its name.  If such a backup already exists, it is
    renamed with an additional '%' added, overwriting any previous such
    file.  Return the opened file object.
    
    By default, the file is opened with the `open` built-in, with 'w'
    mode.  If `opener` is specified, it is used to open the file,
    passing any additional arguments after the file name.
    """
    backup(fname)
    if opener:
        if args:
            fobj = opener(fname, *args, **kwds)
        else:
            fobj = opener(fname)
    else:
        fobj = open(fname, 'w')
    return fobj


class ArrayStore(object):
    """
    A container class that provides persistance of array instance
    attributes via NumPy's .npz archives.
    """
    
    def __init__(self, fname=None):
        """
        Prepare to load arrays from storage if a file name is provided;
        otherwise support saving of assigned array attributes.
        """
        # All internal attributes start with '_' to avoid __setattr__
        # array filtering.
        if fname:
            if not fname.endswith('.npz'):
                fname = fname + '.npz'
                self._npz = load(fname)
        else:
            self._npz = None
        self._fname = fname
        self._archived = {}  # arrays pulled from the archive
        self._new = {}  # arrays to be archived

    def __getattr__(self, name):
        # This is called only if name is not already in the instance dict.
        if self._npz is None:  # no archive to grab attribute from
            raise AttributeError(name)
        else:  # get value from archive and keep a reference to it
            try:
                value = self._npz[name]
                # Set the attribute directly so __setattr__ won't add it
                # to self.new.
                object.__setattr__(self, name, value)
                self._archived[name] = value
                return value
            except:
                raise AttributeError(name)

    def __setattr__(self, name, value):
        # *** Should this prevent over-writing existing names, either
        # directly assigned or yet to be loaded from the archive?
        # Right now we allow reassignments; saving will save the
        # reassigned value.
        if name.startswith('_'):
            object.__setattr__(self, name, value)
        elif isinstance(value, ndarray):
            self._new[name] = value
            object.__setattr__(self, name, value)
        else:
            raise ValueError('Only ndarray objects may be stored!')

    def save(self, fname=None):
        """
        Save array attributes to a NumPy .npz archive.  If a name is
        provided, it is used (adding '.npz' if needed); otherwise it is
        presumed this store was created from an existing archive, and
        that archive's name is used.
        
        In either case, any existing version is backed up before the
        new one is created, with up to two levels of backups (with '%'
        and '%%' suffixes).
        """
        # If no name given, use the name provided at creation.
        if fname is None:
            if self._fname is None:
                raise ValueError('Need a file name for saving!')
            fname = self._fname
        else:
            if not fname.endswith('.npz'):
                fname = fname + '.npz'
        # Gather arrays to store; note new versions supersede old ones.
        arrays = {}
        for name, val in self._archived.items():
            arrays[name] = val
        # Don't forget to get any archived values not already accessed.
        if self._npz:
            for name in self._npz.files:
                if not self._archived.has_key(name):
                    arrays[name] = self._npz[name]
        for name, val in self._new.items():
            arrays[name] = val
        # Backup any existing file, and save the arrays to a new file.
        backup(fname)
        savez(fname, **arrays)

    def contents(self):
        """
        List the names of arrays accessible by this store, including
        both previously archived arrays and newly defined arrays.
        """
        names = []
        if self._npz:
            names.extend(self._npz.files)  # archive file names will be array names
        names.extend(self._new.values())
        return names


if __name__ == '__main__':
    from numpy import *
    store = ArrayStore()
    store.a = array([1,2,3])
    store.b = array([[1., 2.], [3., 4.]])
    store.save('junk')
    as = ArrayStore('junk')
    print as.a
    print as.b
    as.c = eye(6)
    as.a = ones(5, float)
    as.save()
