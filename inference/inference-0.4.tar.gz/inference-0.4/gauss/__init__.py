"""
gauss:  Modules for inference tasks using the Gaussian (normal) distribution.
"""

__all__ = ['vecba']
