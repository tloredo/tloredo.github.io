"""
signals:  Modules implementing various types of parameterized signal models.
"""

__all__ = ['kepler']
